#include "Cjthuecos.hh"
#include <iostream>

using namespace std;

Cjthuecos::Cjthuecos() {
	v = vector<set<Ubicacion>>();
}

Cjthuecos::~Cjthuecos() {}

void Cjthuecos::inicialitza_huecos(int N, int M) {
	v = vector<set<Ubicacion>>(M);	
	for (int i = 1; i <= N; ++i) {
		Ubicacion u(i-1,0,0);
		v[M-1].insert(u);
	} 
}

Segmento Cjthuecos::busca_hueco(int l) {
	Ubicacion u;
	int lhueco = -1; 
	int i = 0;
	set<Ubicacion>::iterator it;
	bool stop = false;
	while (not stop and i <= v.size()-l) {
		if (v[(l-1)+i].empty()) ++i;
		else {
			it = v[(l-1)+i].begin();
			u = (*it);					// Guardem a u la millor ubicació trobada al set (la 1ª)
			lhueco = ((l-1)+i)+1;
			v[(l-1)+i].erase(it);		// Esborra l'ubicació escollida del cjt.
			if (lhueco-l != 0) {
				Ubicacion uretallada(u.hilera(),u.plaza()+l,u.piso());
				it = v[lhueco-l-1].begin();
				v[lhueco-l-1].insert(uretallada);
			}
			stop = true;
		}
	}
	Segmento s(u, lhueco);
	return s;
}

void Cjthuecos::borra_hueco(Ubicacion u, int l) { 
	set<Ubicacion>::iterator it = v[l-1].begin();
	v[l-1].erase(u);
}

void Cjthuecos::crea_hueco(Ubicacion u, int l) {
	v[l-1].insert(u);
}

void Cjthuecos::huecos() const {
	for (int i = 0; i < v.size(); ++i) {
		for (set<Ubicacion>::const_iterator it = v[i].begin(); it != v[i].end(); ++it) {
			cout << '(';
			(*it).print(); // imprimeix ubicació dins la llista
			cout << ',' << i+1 << ')' << endl;
		}
	}
}

/*
#include "Cjthuecos.hh"
#include <iostream>

using namespace std;

Cjthuecos::Cjthuecos() {
	v = vector<list<Ubicacion>>();
}

Cjthuecos::~Cjthuecos() {}

void Cjthuecos::inicialitza_huecos(int N, int M) {
	v = vector<list<Ubicacion>>(M);	
	list<Ubicacion>::iterator it;
	for (int i = 1; i <= N; ++i) {
		it = v[M-1].end();
		Ubicacion u(i-1,0,0);
		v[M-1].insert(it, u);
	} 
}

Segmento Cjthuecos::busca_hueco(int l) {
	Ubicacion u;
	int lhueco = 0; 
	int i = 0;
	list<Ubicacion>::iterator it;
	bool stop = false;
	while (not stop and i <= v.size()-l) {
		if (v[(l-1)+i].empty()) ++i;
		else {
			it = v[(l-1)+i].begin();
			u = (*it);					// Guardem a u la millor ubicació trobada a la llista (la 1ª)
			lhueco = ((l-1)+i)+1;
			it = v[(l-1)+i].erase(it);	// Esborra l'ubicació escollida del cjt.
			if (lhueco-l != 0) {
				Ubicacion uretallada(u.hilera(),u.plaza()+l,u.piso());
				bool colocat = false;
				it = v[lhueco-l-1].begin();
				if (v[lhueco-l-1].empty()) v[lhueco-l-1].insert(it, uretallada);
				else {
					while (not colocat and it != v[lhueco-l-1].end()) {
						if ((*it).hilera() < uretallada.hilera()) ++it;
						else if ((*it).hilera() == uretallada.hilera()) {
							if ((*it).plaza() < uretallada.piso()) ++it;
						} else colocat = true;
					}
					v[lhueco-l-1].insert(it, uretallada);
				}
			}
			stop = true;
		}
	}
	Segmento s(u, lhueco);
	return s;
}

void Cjthuecos::borra_hueco(Ubicacion u, int l) { 
	list<Ubicacion>::iterator it = v[l-1].begin();
	bool stop = false;
	while (not stop and it != v[l-1].end()) {
		if ((*it).hilera() == u.hilera() and (*it).plaza() == u.plaza() and (*it).piso() == u.piso()) {
			it = v[l-1].erase(it); // l'esborrem del conjunt
			stop = true;	 
		} else ++it;
	}
}

void Cjthuecos::crea_hueco(Ubicacion u, int l) {
	list<Ubicacion>::iterator it = v[l-1].begin();
	bool stop = false;
	while (not stop and it != v[l-1].end()) {
		if ((*it).hilera() < u.hilera()) ++it;
		else if ((*it).hilera() == u.hilera()) {
			if ((*it).plaza() < u.piso()) ++it;
		} else stop = true;
	}
	v[l-1].insert(it, u);
}

void Cjthuecos::huecos() const {
	for (int i = 0; i < v.size(); ++i) {
		for (list<Ubicacion>::const_iterator it = v[i].begin(); it != v[i].end(); ++it) {
			cout << '(';
			(*it).print(); // imprimeix ubicació dins la llista
			cout << ',' << i+1 << ')' << endl;
		}
	}
}
*/
