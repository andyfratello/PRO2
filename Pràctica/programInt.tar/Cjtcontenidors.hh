/** @file Cjtcontenidors.hh
    @brief Especificació de la classe Cjtcontenidors
*/
#ifndef _CJTCONTENIDORS_
#define _CJTCONTENIDORS_

#include "Segmento.hh"

#ifndef NO_DIAGRAM
#include <map>
#include <string>
#endif


// Classe Cjtcontenidors

/** @class Cjtcontenidors
	@brief Representa el conjunt de contenidors (Cjtcontenidors)
*/

class Cjtcontenidors {

private:
	map<string, Segmento> d; // identificador -> matrícula (string) ; contingut -> longitud i ubicació (Segmento)


public: 
	// Constructores

	/** @brief Creadora predeterminada
		\pre <em>Cert</em>
		\post El resultat és una àrea d'emmagatzematge buida
	*/
	Cjtcontenidors();

	// Destructora

	/** @brief Destructora
	      \pre <em>Cert</em>
	      \post Destrueix un objecte Cjtcontenidors
	*/   
	~Cjtcontenidors();

	// Modificadores

	/** @brief Modificadora que gestiona l'intent d'insertar un contenidor al conjunt de contenidors
		\pre String m que representa la matrícula, l (> 0) que representa longitud dels contenidors i
			 u que representa l'ubicació on es troba
		\post A partir de m, l i u munta un Contenidor_localitzat (insertat a l'àrea d'emmagatzematge)
			  i el posa a la llista de conjunt de contenidors
	*/
	bool agrega_contenedor(string m, int l, Ubicacion u);

	/** @brief Modificadora que gestiona l'intent de retirar un contenidor de la 
		\pre String m que representa la matrícula
		\post Retira contenidor amb matrícula del conjunt de contenidors. Si té contenidors
			  a sobre els posem a l'àrea d'espera. Un cop retirat el que volíem recol·loquem
			  els que hi ha a l'àrea d'espera. Error si no hi ha cap contenidor amb matrícula m
	*/
	void extreu_contenidor(string m);
    
    void inicialitza_map();

    //void espera(string m, int l, Ubicacion u);

	// Consultores

	/** @brief Consultora d'ubicació de contenidor
		\pre String m que representa la matícula
		\post El resultat és l'ubicació del contenidor amb matrícula m. Si no existeix
			  serà <-1, -1, -1>
	*/
	Ubicacion donde(string m) const;

	/** @brief Consultora de longitud del contenidor
		\pre String m que representa la matícula
		\post El resultat és la longitud del contenidor amb matrícula m. Salta error si
			  no existeix contenidor amb matrícula m
	*/
	int longitud(string m) const;

	// Entrada/Sortida

	/** @brief Operació d'escriptura de tots els contenidors de la terminal
		\pre <em>Cert</em>
		\post Escriu els contenidors en ordre ascendent de la matrícula amb la seva 
			  ubicació i longitud --> m(<i,j,k>,l)
	*/
	void contenedores() const;
	
};

#endif
