/** @file Emmagatzematge.hh
    @brief Especificació de la classe Emmagatzematge
*/
#ifndef _EMMAGATZEMATGE_
#define _EMMAGATZEMATGE_

#include "Cjtcontenidors.hh"
#include "Cjthuecos.hh"
//#include "Espera.hh"

#ifndef NO_DIAGRAM
#include <vector>
#include <list>
#include <string>
#endif

// Classe Emmagatzematge

/** @class Emmagatzematge
	@brief Representa l'àrea d'Emmagatzematge
*/

class Emmagatzematge {

private:
	// Matriu de places*pisos
	vector< vector< vector<string> > > aemmag; // Vector de matrius places*pisos. Cada posició del vec és una fila
	
	int hueco_dreta(Ubicacion u, int l);
	Segmento hueco_esq(Ubicacion u);

public: 
	// Constructores

	/** @brief Creadora predeterminada
		\pre <em>Cert</em>
		\post El resultat és una àrea d'emmagatzematge buida
	*/
	Emmagatzematge();

	// Destructora

	/** @brief Destructora
	      \pre <em>Cert</em>
	      \post Destrueix un objecte Emmagatzematge
	*/   
	~Emmagatzematge();

	// Modificadores

	/** @brief Inicialitza area d'emmagatzematge
		\pre N > 0, M > 0, H > 0
		\post Surt una terminal buida de dimensions N, M, H
	*/
	void crea_terminal(int N, int M, int H);

	/** @brief Modificadora que gestiona l'intent d'insertar un contenidor a la terminal
		\pre String m que representa la matrícula i l (> 0) que representa longitud dels
			 contenidors.
		\post Inserta contenidor amb matrícula m segons l'estratègia BEST_FIT, la qual busca 
			  el millor forat que s'ajusti al seu tamany/longitud l. Si ja existia m surt un
			  error. Surt l'ubicació
	*/
	void inserta_contenedor(Cjtcontenidors &conjcont, Cjthuecos &conjhuecos, /*Espera &aesp,*/ int l, string m);

	/** @brief Modificadora que gestiona l'intent de retirar un contenidor a la terminal
		\pre String m que representa la matrícula
		\post Retira contenidor amb matrícula m segons l'estràtegia BEST_FIT, la qual posa
			  els contenidors sobre el que volem treure a l'àrea d'espera. Un cop retirat
			  el contenidor que volem recol·loquem els que hi ha a l'àrea d'espera. Error
			  si no hi ha cap contenidor amb matrícula m. Surt segment (hueco) que hem creat
	*/
	void retira_contenedor(Cjtcontenidors &conjcont, Cjthuecos &conjhuecos, string m);

	// Consultores

	/** @brief Consultora de número de files a terminal
		\pre <em>Cert</em>
		\post El resultat és el número de files N a la terminal
	*/
	int num_hileras() const;

	/** @brief Consultora de número de places a terminal
		\pre <em>Cert</em>
		\post El resultat és el número de places M a la terminal
	*/
	int num_plazas() const;

	/** @brief Consultora de número de pisos a terminal
		\pre <em>Cert</em>
		\post El resultat és el número de pisos H a la terminal
	*/
	int num_pisos() const;

	/** @brief Consultora de matrícula del contenidor
		\pre String m que representa la matícula
		\post El resultat és la longitud del contenidor amb matrícula m. No s'imprimeix si
		      l'ubicació es troba buida. Salta error si l'ubicació es troba fora de l'àrea
		      d'emmagatzematge
	*/
	string contenedor_ocupa(int i, int j, int k) const;

	// Entrada/Sortida

	/** @brief Operació d'escriptura d'una representació de l'àrea d'emmagatzematge
		\pre <em>Cert</em>
		\post Escriu una representació bidimensional dels contenidors a la seva
			  corresponent fila, columna i pis de la terminal. Si M > 9 a la representació
			  només es mostra l'últim dígit
	*/
	void area_almacenaje() const;

};

#endif
