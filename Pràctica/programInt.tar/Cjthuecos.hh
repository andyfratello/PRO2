/** @file Cjthuecos.hh
    @brief Especificació de la classe Cjthuecos
*/
#ifndef _CJTHUECOS_
#define _CJTHUECOS_

#include "Segmento.hh"

#ifndef NO_DIAGRAM
#include <vector>
#include <set>
#endif

// Classe Cjthuecos

/** @class Cjthuecos
	@brief Representa el conjunt de huecos (Cjthuecos)
*/

class Cjthuecos {

private:
	vector<set<Ubicacion>> v;
	
public: 
	// Constructores

	/** @brief Creadora predeterminada
		\pre <em>Cert</em>
		\post El resultat és una àrea d'emmagatzematge buida
	*/
	Cjthuecos();

	// Destructora

	/** @brief Destructora
	      \pre <em>Cert</em>
	      \post Destrueix un objecte Cjthuecos
	*/   
	~Cjthuecos();

	// Consultores

	Segmento busca_hueco(int l);


	Ubicacion hueco_esquerra(Ubicacion u);

	// Modificadores

	void inicialitza_huecos(int N, int M);

	/** @brief Modificadora que gestiona l'intent de crear un hueco al conjunt de huecos
		\pre u representa l'ubicació del hueco que s'ha de crear i l és la longitud
		\post A partir d'u i l busquem a la llista el lloc correcte per crear ia afegir el nou hueco
	*/
	void crea_hueco(Ubicacion u, int l);

	void borra_hueco(Ubicacion u, int l);

	// Entrada/Sortida

	/** @brief Operació d'escriptura dels buits a la terminal
		\pre <em>Cert</em>
		\post Escriu tots els forats a la terminal, els quals s'indica la seva ubicació
			  i longitud, ordenats en ordre ascendent de tamany. En cas d'empat de menor 
			  a major fila i, en cas d'un altre empat, de menys a més plaça
	*/
	void huecos() const;
};

#endif
