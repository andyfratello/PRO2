/** @mainpage
	Pràctica de PRO2 Gestió d'una terminal de contenidors

	El programa principal es troba al mòdul main.cc.
	Atenent als tipus de dades suggerides per l'enunciat, necessitem diversos mòduls:
	un per representar l'àrea d'emmagatzematge de la terminal (Emmagatzematge), un per l'àrea
	d'espera (Espera), un per el conjunt de contenidors (Cjtcontenidors) i un altre pel 
	conjunt de buits (Cjthuecos). A part tenim 3 mòduls més que representen els contenidors
	(Contenedor), les ubicacions (Ubicacion) i els segments (Segmento)
*/

/** @file main.cc
	@brief Programa principal

*/

#include "Emmagatzematge.hh"
#include "Cjtcontenidors.hh"
#include "Cjthuecos.hh"
//#include "Espera.hh"

#ifndef NO_DIAGRAM
#include <iostream>
#endif

int main() {
	string command = "";
	cin >> command;
	Segmento s;
	Ubicacion u;
	Emmagatzematge aemmag;
	//Espera aesp;
	Cjtcontenidors conjcont;
	Cjthuecos conjhuecos;
	while (command != "fin") {
		int N, M, H;
		if (command == "crea_terminal") {
			cin >> N >> M >> H;
			cout << "#crea_terminal " << N << ' ' << M << ' ' << H << endl;
			aemmag.crea_terminal(N, M, H);
            //aesp.inicialitza();
            conjcont.inicialitza_map();
			conjhuecos.inicialitza_huecos(N, M);
		}
		cin >> command;
		string m;
		int l;
		while (command != "fin" and command != "crea_terminal") {
			if (command == "inserta_contenedor" or command == "i") {
				cin >> m >> l;
				if (command == "i") cout << "#i ";
				else cout << "#inserta_contenedor ";
				cout << m << ' ' << l << endl;
				aemmag.inserta_contenedor(conjcont, conjhuecos, /*aesp,*/ l, m);	 
			} else if (command == "retira_contenedor" or command == "r") {
				cin >> m;
				if (command == "r") cout << "#r ";
				else cout << "#retira_contenedor ";
				cout << m << endl;
				aemmag.retira_contenedor(conjcont, conjhuecos, m);
			} else if (command == "donde") {
				cin >> m;
                cout << "#donde " << m << endl;
				u = conjcont.donde(m);
				u.print();
				cout << endl;
			} else if (command == "longitud") {
				cin >> m;
				l = conjcont.longitud(m);
				cout << "#longitud " << m << endl;
				if (l == -1) cout << "error: el contenedor no existe" << endl;
				else cout << l << endl;
			} else if (command == "contenedor_ocupa") {
				int i, j, k;
				cin >> i >> j >> k;
				cout << "#contenedor_ocupa " << i << ' ' << j << ' ' << k << endl;
				if (i > N-1 or j > M-1 or k > H-1) cout << "error: ubicacion fuera de rango" << endl;
				else if (aemmag.contenedor_ocupa(i, j, k) == "0" or aemmag.contenedor_ocupa(i, j, k) == "-1") cout << endl;
				else cout << aemmag.contenedor_ocupa(i, j, k) << endl;
			} 
			else if (command == "num_hileras") {
                cout << "#num_hileras" << endl;
                cout << aemmag.num_hileras() << endl;
            } 
            else if (command == "num_plazas") {
                cout << "#num_plazas" << endl;
                cout << aemmag.num_plazas() << endl;
            }
			else if (command == "num_pisos") {
                cout << "#num_pisos" << endl;
                cout << aemmag.num_pisos() << endl;
            }/*
			else if (command == "area_espera") {
                cout << "#area_espera" << endl;
				aesp.area_espera();
				cout << endl;
			}*/
			else if (command == "contenedores") {
                cout << "#contenedores" << endl;
                conjcont.contenedores();
                cout << endl;
            }
			else if (command == "area_almacenaje") {
                cout << "#area_almacenaje" << endl;
                aemmag.area_almacenaje();
            }
			else if (command == "huecos") {
                cout << "#huecos" << endl;
                conjhuecos.huecos();
                cout << endl;
            }
			cin >> command;
		}
	}
}
