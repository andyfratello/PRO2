#include "Emmagatzematge.hh"
#include <iostream>

using namespace std;

Emmagatzematge::Emmagatzematge() {
	aemmag = vector<vector<vector<string> > >();
}

Emmagatzematge::~Emmagatzematge() {
}

void Emmagatzematge::crea_terminal(int N, int M, int H) {
	aemmag = vector<vector<vector<string> > >(N,vector<vector<string>>(M, vector<string>(H,"-1")));
    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < M; ++j) {
            aemmag[i][j][0] = "0";
        }
    }
}

int Emmagatzematge::hueco_dreta(Ubicacion u, int l) {
    int ldre = 0;
    int i = u.plaza()+l;
    bool stop = false;
    while (not stop and i < aemmag[0].size()) {
        if (aemmag[u.hilera()][i][u.piso()] == "0") {
            ++ldre;
            ++i;
        } else stop = true;
    }
    return ldre;
}

Segmento Emmagatzematge::hueco_esq(Ubicacion u) {
    int lleft = 0;
    int i = u.plaza()-1;
    bool stop = false;
    while (not stop and i >= 0) {
        if (aemmag[u.hilera()][i][u.piso()] == "0") {
            ++lleft;
            --i;
        } else stop = true;
    }
    Ubicacion uleft(u.hilera(),i+1,u.piso());
    Segmento s(uleft,lleft);
    return s;
}

void Emmagatzematge::inserta_contenedor(Cjtcontenidors &conjcont, Cjthuecos &conjhuecos, /*Espera &aesp,*/ int l, string m) {
    Segmento s = conjhuecos.busca_hueco(l);				 // busca hueco i l'esborra/retalla del conjunt
    int lhueco = s.longitud();	    					 // long hueco
    Ubicacion u = s.ubic();                              // ubicació hueco
    bool entra = false;								
    if (lhueco != -1) entra = conjcont.agrega_contenedor(m, l, u); 	 // afegeix al cjtcontenidors el contenidor

    if (entra and lhueco != -1) {
        // pinta la matriu amb la nova matrícula i els nous huecos
        for (int i = 0; i < l; ++i) {
            aemmag[u.hilera()][u.plaza()+i][u.piso()] = m;
            if (u.piso()+1 <= aemmag[0][0].size()-1) aemmag[u.hilera()][u.plaza()+i][u.piso()+1] = "0";
        }
        // tots els pisos que no siguin el més alt
        if (u.piso()+1 <= aemmag[0][0].size()-1) {
            Ubicacion utop(u.hilera(),u.plaza(),u.piso()+1); // ubic hueco sobre contenidor insertat

            // hueco dret
            int lright = 0;
            if (lhueco-l == 0 and u.plaza()+l < aemmag[0].size() and aemmag[u.hilera()][u.plaza()+l][u.piso()] != "-1") {   // si no hi ha un hueco entre el contenidor de la dreta
                Ubicacion uright(u.hilera(),u.plaza()+l,u.piso()+1);
                lright = hueco_dreta(utop,l);
                
                if (lright != 0) conjhuecos.borra_hueco(uright,lright);
                if (u.plaza() == 0 or (u.plaza()-1 >= 0 and (aemmag[u.hilera()][u.plaza()-1][u.piso()] == "-1" or aemmag[u.hilera()][u.plaza()-1][u.piso()] == "0")) 
                    or (u.plaza()-1 >= 0 and (aemmag[u.hilera()][u.plaza()-1][u.piso()+1] != "0"))) {
                    conjhuecos.crea_hueco(utop,l+lright);
                }
            }

            // hueco esquerra
            Segmento esq = hueco_esq(utop);
            if (esq.longitud() != 0) {                                                         // si a l'esquerra hi ha un hueco
                conjhuecos.borra_hueco(esq.ubic(),esq.longitud());                             // Busca al cjt. huecos un hueco amb l'ubicació passada per paràmetre i elimina del cjt

                if (lright != 0) conjhuecos.crea_hueco(esq.ubic(),l+esq.longitud()+lright);    // té contenidors als dos costats
                else conjhuecos.crea_hueco(esq.ubic(),l+esq.longitud());                       // Només té un contenidor a l'esquerra. Crea un hueco de mida l + lleft
            } 

            // No té cap contenidor al costat
            if (esq.longitud() == 0 and lright == 0) conjhuecos.crea_hueco(utop,l);
        } 
    } else if (not entra and lhueco != -1) { // esborrem el hueco que hem creat per un contenidor que no hem de posar
        if (lhueco-l != 0) {
            Ubicacion uretallada(u.hilera(),u.plaza()+l,u.piso());
            conjhuecos.borra_hueco(uretallada,lhueco-l); 
        }
        conjhuecos.crea_hueco(u,lhueco);
    } /*else if (lhueco == -1) {
        aesp.inserta_espera(m, l, conjcont);
    }*/
    /*
    //recoloquem contenidors de l'àrea d'espera
    if (lhueco != -1) { // si no s'acaba d'afegir un contenidor a l'àrea d'espera
        list<Contenedor>::iterator it;
        for (it = aesp.begin(); it != aesp.end(); ++it) {
            string mat = (*it).matricula();
            int lon = (*it).longitud();
            aemmag.inserta_contenedor(conjcont,conjhuecos,aesp,l,m);
        }
    }*/
}

void Emmagatzematge::retira_contenedor(Cjtcontenidors &conjcont, Cjthuecos &conjhuecos, string m) {
    Ubicacion u = conjcont.donde(m);        // Busquem l'ubicació del contenidor que volem treure
    int l = conjcont.longitud(m);           // Busquem la longitud del contenidor que volem treure

    conjcont.extreu_contenidor(m); 			// actualitza llista conj contendidors extraient m

    if (l != -1) {
    	for (int i = 0; i < l; ++i) {
            if (u.piso() < aemmag[0][0].size()-1) aemmag[u.hilera()][u.plaza()+i][u.piso()+1] = "-1";
    		aemmag[u.hilera()][u.plaza()+i][u.piso()] = "0";
    	}

        Ubicacion utop(u.hilera(),u.plaza(),u.piso()+1);
        if (u.piso() < aemmag[0][0].size()-1) {
            /////////////////////////////////////////////////////////////////////////////////////////////
            // té un contenidor a la dreta
            int lright = hueco_dreta(utop,l);
            Ubicacion uright(u.hilera(),u.plaza()+l,u.piso()+1);
            if (lright != 0) {
                if (u.plaza() == 0 or (u.plaza()-1 >= 0 and (aemmag[u.hilera()][u.plaza()-1][u.piso()] == "-1" or aemmag[u.hilera()][u.plaza()-1][u.piso()] == "0")) 
                    or (u.plaza()-1 >= 0 and (aemmag[u.hilera()][u.plaza()-1][u.piso()+1] != "0"))) {
                    conjhuecos.borra_hueco(utop,l+lright);
                    conjhuecos.crea_hueco(uright,lright);
                }
                // enganxem el hueco creat amb el que hi ha a l'esquerra
                Segmento esq = hueco_esq(u);
                if (esq.longitud() != 0) conjhuecos.borra_hueco(esq.ubic(),esq.longitud());
                conjhuecos.crea_hueco(esq.ubic(),esq.longitud()+l); 
            }
            ////////////////////////////////////////////////////////////////////////////////////////////
            // té un contenidor a l'esquerra 
            Segmento esq = hueco_esq(utop);
            if (esq.longitud() != 0) { 
                if (lright != 0) {          // té un contenidor a cada costat
                    conjhuecos.borra_hueco(esq.ubic(),l+esq.longitud()+lright);
                    conjhuecos.crea_hueco(uright,lright);
                    conjhuecos.crea_hueco(esq.ubic(),esq.longitud());

                } else {                    // té només un contenidor a l'esquerra
                    conjhuecos.borra_hueco(esq.ubic(),l+esq.longitud());
                    conjhuecos.crea_hueco(esq.ubic(),esq.longitud());

                    // enganxem el hueco creat amb el que hi ha a la dreta
                    int ldre = hueco_dreta(u,l);
                    Ubicacion ubot_right(u.hilera(),u.plaza()+l,u.piso());
                    if (ldre != 0) conjhuecos.borra_hueco(ubot_right,ldre);
                    conjhuecos.crea_hueco(u,l+ldre); 
                }
            }
            ////////////////////////////////////////////////////////////////////////////////////////////
            // contenidor no té cap al costat
            if (esq.longitud() == 0 and lright == 0) {
                conjhuecos.borra_hueco(utop,l);
                // eliminem el hueco de la dreta
                int ldre = hueco_dreta(u,l);
                Ubicacion ubot_right(u.hilera(),u.plaza()+l,u.piso());
                if (ldre != 0) conjhuecos.borra_hueco(ubot_right,ldre);

                // enganxem el hueco de l'esquerra amb el hueco que es crea + el de la dreta
                Segmento left = hueco_esq(u);
                if (left.longitud() != 0) conjhuecos.borra_hueco(left.ubic(),left.longitud());
                conjhuecos.crea_hueco(left.ubic(),l+left.longitud()+ldre);
            }
        } else if (u.piso() == aemmag[0][0].size()-1) { // últim pis
            // dreta
            Segmento esq = hueco_esq(u);
            if (esq.longitud() != 0) conjhuecos.borra_hueco(esq.ubic(),esq.longitud());
            if (u.plaza()+l < aemmag[0].size() and aemmag[u.hilera()][u.plaza()+l][u.piso()] != "0") {
                conjhuecos.crea_hueco(esq.ubic(),esq.longitud()+l);
            }

            // esquerra
            int ldre = hueco_dreta(u,l);
            Ubicacion ubot_right(u.hilera(),u.plaza()+l,u.piso());
            if (ldre != 0) conjhuecos.borra_hueco(ubot_right,ldre);
            if (u.plaza()-1 >= 0 and aemmag[u.hilera()][u.plaza()-1][u.piso()] != "0") {
                conjhuecos.crea_hueco(u,l+ldre); 
            }

            // cap al costat
            if ((u.plaza() == 0 and ldre != 0) or (u.plaza()+l-1 == aemmag[0].size()-1 and esq.longitud() != 0) or (esq.longitud() != 0 and ldre != 0) or (u.plaza() == 0 and u.plaza()+l-1 == aemmag[0].size()-1)) {
                conjhuecos.crea_hueco(esq.ubic(),esq.longitud()+ldre+l);
            }
        }
    }
}

int Emmagatzematge::num_hileras() const {
	return aemmag.size();
}

int Emmagatzematge::num_plazas() const {
	return aemmag[0].size();
}

int Emmagatzematge::num_pisos() const {
	return aemmag[0][0].size();
}

string Emmagatzematge::contenedor_ocupa(int i, int j, int k) const {
	return aemmag[i][j][k];
}

void Emmagatzematge::area_almacenaje() const {
	int x = aemmag.size(); 		// hilera
	int y = aemmag[0].size();		// piso
	int z = aemmag[0][0].size();	// plaza
	for (int i = 0; i < x; ++i) {
		cout << "hilera " << i << endl;
		for (int j = 0; j < z; ++j) {
			cout << z-j-1 << ' ';
			for (int k = 0; k < y; ++k) {
				if (aemmag[i][k][z-j-1] == "0" or aemmag[i][k][z-j-1] == "-1") cout << ' ';
                else cout << aemmag[i][k][z-j-1][0];
			} 
			cout << endl;
		}
        cout << "  ";
        for (int i = 0; i < y; ++i) cout << i%10; // quan les places > 9
        cout << endl << endl;
	}
}
