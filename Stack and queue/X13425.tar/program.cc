#include "CuaIOParInt.hh"
#include <queue>
using namespace std;

void distribuir(queue<ParInt>& q, queue<ParInt>& q0, queue<ParInt>& q1) {
	int time0 = 0;
	int time1 = 0;
	while (not q.empty()) {
		ParInt first = q.front();
		int time = first.segon();
		if (time0 + time > time1 + time) {
			time1 += time;
			q1.push(first);
		} else {
			time0 += time;
			q0.push(first);
		}
		q.pop();
	}
}

int main() {
	//llegir
	queue<ParInt> q;
	llegirCuaParInt(q);
	//distribuir
	queue<ParInt> q0;
	queue<ParInt> q1;
	distribuir(q, q0, q1);
	//escriure
	escriureCuaParInt(q0);
	cout << endl;
	escriureCuaParInt(q1);
}