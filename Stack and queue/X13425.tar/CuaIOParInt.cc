#include "CuaIOParInt.hh"

void llegirCuaParInt(queue<ParInt>& c) {
	ParInt p;
	while (p.llegir()) c.push(p); 
}

void escriureCuaParInt(queue<ParInt> c) {
	queue<ParInt> a = c;
	while (not a.empty()) {
		a.front().escriure();
		a.pop();
	}
}