#include <iostream>
#include "ParInt.hh"
#include "LlistaIOParInt.hh"
using namespace std;

int main() {
    list<ParInt> l;
    LlegirLlistaParInt(l);
    int n;
    cin >> n;
    list<ParInt>::const_iterator it;
    int count = 0;
    int sum = 0;
    for (it = l.begin(); it != l.end(); ++it) {
        if ((*it).primer() == n) {
            ++count;
            sum += (*it).segon();
        }
    }
    cout << n << ' ' << count << ' ' << sum << endl; 
}
