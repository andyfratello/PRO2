#include <list>
#include "ParInt.hh"
#include "LlistaIOParInt.hh"

void LlegirLlistaParInt(list<ParInt>& l) {
    list<ParInt>::iterator it = l.end();
    ParInt p;
    p.llegir();
    while (p.primer() != 0 and p.segon() != 0) {
        l.insert(it, p);
        p.llegir();
    }
}

void EscriureLlistaParInt(const list<ParInt>& l) {
    list<ParInt>::const_iterator it;
    for (it = l.begin(); it != l.end(); ++it) {
        (*it).escriure();
    }
}
