#include "BinTreeIOParInt.hh"

void read_bintree_parint(BinTree<ParInt>& a) {
	ParInt p;
	if(p.llegir()) {
		BinTree<ParInt> b;
		BinTree<ParInt> c;
		read_bintree_parint(b);
		read_bintree_parint(c);
		a = BinTree<ParInt> (p, b, c);
	}
}

void write_bintree_parint(const BinTree<ParInt>& a) {
	write_bintree_parint(a.right());
	a.value().escriure();
	write_bintree_parint(a.left());
}