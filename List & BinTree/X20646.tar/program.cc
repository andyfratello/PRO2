#include <iostream>
#include "BinTree.hh"
#include "ParInt.hh"
#include "BinTreeIOParInt.hh"
using namespace std;

int search_position(const BinTree<ParInt>& b, int& n, int& company) {
	if (not b.empty()) {
		if (b.value().primer() == n) {
			company = b.value().segon();
			return 0;
		}
		int left = search_position(b.left(), n, company);
		if (left != -1) return 1 + left;
		int right = search_position(b.right(), n, company);
		if (right != -1) return 1 + right;
	}
	return -1;
}

int main() {
	BinTree<ParInt> b;
	read_bintree_parint(b);
	int n, company;
	while (cin >> n) {
		int pos = search_position(b, n, company);
		if (pos == -1) cout << -1 << endl;
		else cout << n << ' ' << company << ' ' << pos << endl;
	}
}