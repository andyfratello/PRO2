#include <list>
#include "Estudiant.hh"
#include "LlistaIOEstudiant.hh"

void LlegirLlistaEstudiant(list<Estudiant>& l) {
    list<Estudiant>::iterator it = l.end();
    Estudiant p;
    p.llegir();
    while (p.consultar_DNI() != 0) {
        l.insert(it, p);
        p.llegir();
    }
}

void EscriureLlistaEstudiant(const list<Estudiant>& l) {
    list<Estudiant>::const_iterator it;
    for (it = l.begin(); it != l.end(); ++it) {
        (*it).escriure();
    }
}
