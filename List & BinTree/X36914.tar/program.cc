#include <iostream>
#include "LlistaIOEstudiant.hh"
#include "Estudiant.hh"
using namespace std;

int main() {
	list<Estudiant> l;
	LlegirLlistaEstudiant(l);
	int n;
	cin >> n;
	list<Estudiant>::iterator it;
	int count = 0;
	for (it = l.begin(); it != l.end(); ++it) {
		if (n == (*it).consultar_DNI()) ++count;
	} 
	cout << n << ' ' << count << endl;
}
