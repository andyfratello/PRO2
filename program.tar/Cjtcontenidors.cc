/** @file Cjtcontenidors.cc
    @brief Código de la clase Cjtcontenidors
*/

#include "Cjtcontenidors.hh"

using namespace std;

Cjtcontenidors::Cjtcontenidors() {
	d = map<string, Segmento>();
}

Cjtcontenidors::~Cjtcontenidors() {
}

void Cjtcontenidors::inicialitza_map() {
    d.clear();
}

bool Cjtcontenidors::agrega_contenedor(string m, int l, Ubicacion u, bool fromespera) {
	map<string, Segmento>::iterator it = d.find(m);
	if (it != d.end()) {
		cout << "error: el contenedor ya existe" << endl;
		return false;
	}
	Segmento s(u,l);
	d.insert(make_pair(m, s));
	if (not fromespera) {
		u.print();
		cout << endl;
	}
	return true;
}

void Cjtcontenidors::extreu_contenidor(string m) {
	map<string, Segmento>::iterator it = d.find(m);
	if (it == d.end()) cout << "error: el contenedor no existe" << endl;
	else d.erase(it);
}

void Cjtcontenidors::espera(string m, int l, Ubicacion u) {
	map<string, Segmento>::iterator it = d.find(m);
    if (it != d.end()) it->second = Segmento(u,l);
    else d.insert(make_pair(m, Segmento(u,l)));
}

Ubicacion Cjtcontenidors::donde(string m) const {
	Ubicacion u;
	map<string, Segmento>::const_iterator it = d.find(m);
	if (it != d.end()) u = it->second.ubic();
	else u = Ubicacion(-1,-1,-1);
	return u;
}

int Cjtcontenidors::longitud(string m) const {
	int l;
	map<string, Segmento>::const_iterator it = d.find(m);
	if (it == d.end()) l = -1;
	else l = it->second.longitud();
	return l;
}

void Cjtcontenidors::contenedores() const {
	map<string, Segmento>::const_iterator it;
	for (it = d.begin(); it != d.end(); ++it) {
		cout << it->first;
		it->second.print();
		cout << endl;
	}
}
