/** @file Espera.hh
    @brief Especificació de la classe Espera
*/
#ifndef _ESPERA_
#define _ESPERA_

#include "Contenedor.hh"
#include "Cjthuecos.hh"
#include "Cjtcontenidors.hh"

#ifndef NO_DIAGRAM
#include <iostream>
#include <list>
#endif

// Classe Espera

/** @class Espera
	@brief Representa l'àrea d'Espera
*/

class Espera {

private:
	list<Contenedor> aespera; 
	list<Contenedor>::iterator it;

public: 
	// Constructores

	/** @brief Creadora predeterminada
		\pre <em>Cert</em>
		\post El resultat és una àrea d'espera buida
	*/
	Espera();

	// Destructora

	/** @brief Destructora
	      \pre <em>Cert</em>
	      \post Destrueix un objecte Espera
	*/  
	~Espera();

	// Consultores

	/** @brief Consultora del contenidor a la ièssima posició de l'iterador
		\pre Enter i que representa la posició de l'iterador
		\post El resultat és el contenidor a la ièssima posició de la llista
	*/
	Contenedor elemento_iavo_zona_espera(int i);

	/** @brief Consultora de la mida de la llista de l'àrea d'espera
		\pre <em>Cert</em>
		\post El resultat és a mida de l'àrea d'espera
	*/
	int mida();

	// Modificadores

	/** @brief Modificadora que inicialitza a buida l'àrea d'espera
		\pre <em>Cert</em>
		\post Inicialitza l'àrea d'espera
	*/
    void inicialitza();
    
	/** @brief Modificadora que gestiona l'intent d'insertar un contenidor a l'àrea d'espera
		\pre String m que representa la matrícula i l (> 0) que representa longitud dels
			 contenidors.
		\post Inserta contenidor amb matrícula m a l'àrea d'espera. Actualitza conjunt de
			  contenidors caviant l'ubicació del contenidor a <-1,0,0>
	*/
	void inserta_espera(string m, int l, Cjtcontenidors &conjcont);

	/** @brief Modificadora que gestiona l'intent de retirar un contenidor de l'àrea d'espera
		\pre String m que representa la matrícula
		\post Retira contenidor de l'àrea d'espera amb matrícula m
	*/
	void retira_espera(string m);

	// Entrada / Sortida 

	/** @brief Operació d'escriptura de l'àrea d'espera
		\pre <em>Cert</em>
		\post Escriu els contenidors de l'àrea d'espera. Una línia per contenidor on es
			  mostra la matrícula i la longitud --> m(l)
	*/
	void area_espera() const;
};
#endif
