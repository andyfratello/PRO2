/** @file Espera.cc
    @brief Código de la clase Espera
*/

#include "Espera.hh"

using namespace std;

Espera::Espera() {
	aespera = list<Contenedor>();
	it = list<Contenedor>::iterator();
}

Espera::~Espera() {
}

void Espera::inicialitza() {
    aespera.clear();
}

void Espera::inserta_espera(string m, int l, Cjtcontenidors &conjcont) {
	conjcont.espera(m, l, Ubicacion(-1,0,0));
	it = aespera.begin();
	Contenedor c(m, l);
	aespera.insert(it, c);
}

void Espera::retira_espera(string m) {
	it = aespera.begin();
	bool stop = false;
	while (not stop and it != aespera.end()) {
		if ((*it).matricula() != m) ++it;
		else {
			it = aespera.erase(it);
			stop = true;
		}
	}
}

int Espera::mida() {
	return aespera.size();
}

Contenedor Espera::elemento_iavo_zona_espera(int i) {
	it = aespera.begin();
	for (int j = 0; j < i; ++j) ++it;
	return (*it);
}

void Espera::area_espera() const {
	list<Contenedor>::const_iterator it;
	for (it = aespera.begin(); it != aespera.end(); ++it) {
		(*it).print(); cout << endl;
	}
}
