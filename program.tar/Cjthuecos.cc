/** @file Cjthuecos.cc
    @brief Código de la clase Cjthuecos
*/

#include "Cjthuecos.hh"

using namespace std;

Cjthuecos::Cjthuecos() {
	v = vector<set<Ubicacion>>();
}

Cjthuecos::~Cjthuecos() {}

void Cjthuecos::inicialitza_huecos(int N, int M) {
	v = vector<set<Ubicacion>>(M);	
	for (int i = 1; i <= N; ++i) {
		Ubicacion u(i-1,0,0);
		v[M-1].insert(u);
	} 
}

Segmento Cjthuecos::busca_hueco(int l) {
	Ubicacion u;
	int lhueco = -1; 
	int i = 0;
	set<Ubicacion>::iterator it;
	bool stop = false;
	while (not stop and i <= v.size()-l) {
		if (v[(l-1)+i].empty()) ++i;
		else {
			it = v[(l-1)+i].begin();
			u = (*it);					// Guardem a u la millor ubicació trobada al set (la 1ª)
			lhueco = ((l-1)+i)+1;
			v[(l-1)+i].erase(it);		// Esborra l'ubicació escollida del cjt.
			if (lhueco-l != 0) {
				Ubicacion uretallada(u.hilera(),u.plaza()+l,u.piso());
				it = v[lhueco-l-1].begin();
				v[lhueco-l-1].insert(uretallada);
			}
			stop = true;
		}
	}
	Segmento s(u, lhueco);
	return s;
}

void Cjthuecos::borra_hueco(Ubicacion u, int l) { 
	set<Ubicacion>::iterator it = v[l-1].begin();
	v[l-1].erase(u);
}

void Cjthuecos::crea_hueco(Ubicacion u, int l) {
	v[l-1].insert(u);
}

void Cjthuecos::huecos() const {
	for (int i = 0; i < v.size(); ++i) {
		for (set<Ubicacion>::const_iterator it = v[i].begin(); it != v[i].end(); ++it) {
			cout << '(';
			(*it).print(); // imprimeix ubicació dins la llista
			cout << ',' << i+1 << ')' << endl;
		}
	}
}