/** @file Emmagatzematge.hh
    @brief Especificació de la classe Emmagatzematge
*/
#ifndef _EMMAGATZEMATGE_
#define _EMMAGATZEMATGE_

#include "Cjtcontenidors.hh"
#include "Cjthuecos.hh"
#include "Espera.hh"

#ifndef NO_DIAGRAM
#include <vector>
#include <iostream>
#include <string>
#endif

// Classe Emmagatzematge

/** @class Emmagatzematge
	@brief Representa l'àrea d'Emmagatzematge
*/

class Emmagatzematge {

private:
	// Matriu de places*pisos
	vector< vector< vector<string> > > aemmag; // Vector de matrius places*pisos. Cada posició del vec és una fila
	
	int hueco_dreta(Ubicacion u, int l);	   // Busca hueco a la dreta de l'ubicació i retorna la seva longitud
	Segmento hueco_esq(Ubicacion u);		   // Busca hueco a l'esquerra de l'ubicació i retorna el Segmento d'aquest hueco 
	void recoloca(Cjtcontenidors &conjcont, Cjthuecos &conjhuecos, Espera &aesp); // Recol·loca els contenidors de l'àrea d'espera a l'àrea d'emmagatzematge

public: 
	// Constructores

	/** @brief Creadora predeterminada
		\pre <em>Cert</em>
		\post El resultat és una àrea d'emmagatzematge buida
	*/
	Emmagatzematge();

	// Destructora

	/** @brief Destructora
	      \pre <em>Cert</em>
	      \post Destrueix un objecte Emmagatzematge
	*/   
	~Emmagatzematge();

	// Modificadores

	/** @brief Inicialitza area d'emmagatzematge
		\pre N > 0, M > 0, H > 0
		\post Surt una terminal buida de dimensions N, M, H
	*/
	void crea_terminal(int N, int M, int H);

	/** @brief Modificadora que gestiona l'intent d'insertar un contenidor a la terminal
		\pre String m que representa la matrícula, l (> 0) que representa la longitud del
			 contenidor, se que representa el Segmento del hueco on s'insertarà el
			 contenidor i bool fromespera que representa un boleà que ens indica si el contenidor
			 que s'insertarà prové de l'àrea d'espera o no 
		\post Inserta contenidor amb matrícula m segons l'estratègia BEST_FIT, la qual busca 
			  el millor forat que s'ajusti al seu tamany/longitud l. Actualitza el conjunt de
			  contenidors, el conjunt de huecos i l'àrea d'espera
	*/
	void inserta_contenedor(Cjtcontenidors &conjcont, Cjthuecos &conjhuecos, Espera &aesp, int l, string m, Segmento se, bool fromespera);

	/** @brief Modificadora que gestiona l'intent de retirar un contenidor a la terminal
		\pre String m que representa la matrícula, string matricula que representa la matrícula
			 del contenidor a retirar, Ubicacion u del contenidor, l (> 0) que representa
			 la longitud del contenidor
		\post Retira contenidor amb matrícula m segons l'estràtegia BEST_FIT, la qual posa
			  els contenidors sobre el que volem treure a l'àrea d'espera. Un cop retirat
			  el contenidor que volem recol·loquem els que hi ha a l'àrea d'espera. Actualitza 
			  el conjunt de contenidors, el conjunt de huecos i l'àrea d'espera
	*/
	void retira_contenedor(Cjtcontenidors &conjcont, Cjthuecos &conjhuecos, Espera &aesp, string m, const string matricula, Ubicacion u, int l);

	// Consultores

	/** @brief Consultora de número de files a terminal
		\pre <em>Cert</em>
		\post El resultat és el número de files N a la terminal
	*/
	int num_hileras() const;

	/** @brief Consultora de número de places a terminal
		\pre <em>Cert</em>
		\post El resultat és el número de places M a la terminal
	*/
	int num_plazas() const;

	/** @brief Consultora de número de pisos a terminal
		\pre <em>Cert</em>
		\post El resultat és el número de pisos H a la terminal
	*/
	int num_pisos() const;

	/** @brief Consultora de matrícula del contenidor
		\pre Les coordenades i, j, k que representen la ubicació
		\post El resultat és la matrícula del contenidor que ocupa la ubicació i, j, k.
			  Retorna "0" o "-1" si no hi ha cap contenidor a aquestes coordenades
	*/
	string contenedor_ocupa(int i, int j, int k) const;

	// Entrada/Sortida

	/** @brief Operació d'escriptura d'una representació de l'àrea d'emmagatzematge
		\pre <em>Cert</em>
		\post Escriu una representació bidimensional dels contenidors a la seva
			  corresponent fila, columna i pis de la terminal. Si M > 9 a la representació
			  només es mostra l'últim dígit
	*/
	void area_almacenaje() const;

};

#endif
