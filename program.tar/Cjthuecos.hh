/** @file Cjthuecos.hh
    @brief Especificació de la classe Cjthuecos
*/
#ifndef _CJTHUECOS_
#define _CJTHUECOS_

#include "Segmento.hh"

#ifndef NO_DIAGRAM
#include <iostream>
#include <vector>
#include <set>
#endif

// Classe Cjthuecos

/** @class Cjthuecos
	@brief Representa el conjunt de huecos (Cjthuecos)
*/

class Cjthuecos {

private:
	vector<set<Ubicacion>> v;
	
public: 
	// Constructores

	/** @brief Creadora predeterminada
		\pre <em>Cert</em>
		\post El resultat és una àrea d'emmagatzematge buida
	*/
	Cjthuecos();

	// Destructora

	/** @brief Destructora
	      \pre <em>Cert</em>
	      \post Destrueix un objecte Cjthuecos
	*/   
	~Cjthuecos();

	// Consultores

	/** @brief Consultora del millor hueco a partir d'una longitud 
		\pre Enter l que representa la longitud. l > 0
		\post El resultat és el Segmento que representa el millor
			  hueco trobat al conjunt.
	*/
	Segmento busca_hueco(int l);

	// Modificadores

	/** @brief Modificadora que inicialitza els huecos al conjunt de huecos
		\pre N > 0, M > 0
		\post Inicialitza el conjunt de huecos
	*/
	void inicialitza_huecos(int N, int M);

	/** @brief Modificadora que gestiona l'intent de crear un hueco al conjunt de huecos
		\pre u representa l'ubicació del hueco que s'ha de crear i l és la longitud
		\post A partir d'u i l posem al set de la posició l-1 del vector l'ubicació al lloc
			  que li toca seguint l'ordre de l'operador operator< de la classe Ubicacion
	*/
	void crea_hueco(Ubicacion u, int l);

	/** @brief Modificadora que gestiona l'intent d'esborrar un hueco del conjunt de huecos
		\pre u representa l'ubicació del hueco que s'ha d'esborrar i l és la longitud
		\post A partir d'u i l esborrem l'ubicació del set de la posició l-1 del vector
	*/
	void borra_hueco(Ubicacion u, int l);

	// Entrada/Sortida

	/** @brief Operació d'escriptura dels buits a la terminal
		\pre <em>Cert</em>
		\post Escriu tots els forats a la terminal, els quals s'indica la seva ubicació
			  i longitud, ordenats en ordre ascendent de tamany. En cas d'empat de menor 
			  a major fila i, en cas d'un altre empat, de menys a més plaça
	*/
	void huecos() const;
};

#endif
