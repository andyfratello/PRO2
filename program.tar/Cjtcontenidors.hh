/** @file Cjtcontenidors.hh
    @brief Especificació de la classe Cjtcontenidors
*/
#ifndef _CJTCONTENIDORS_
#define _CJTCONTENIDORS_

#include "Segmento.hh"

#ifndef NO_DIAGRAM
#include <iostream>
#include <map>
#include <string>
#endif


// Classe Cjtcontenidors

/** @class Cjtcontenidors
	@brief Representa el conjunt de contenidors (Cjtcontenidors)
*/

class Cjtcontenidors {

private:
	map<string, Segmento> d; // identificador -> matrícula (string) ; contingut -> longitud i ubicació (Segmento)


public: 
	// Constructores

	/** @brief Creadora predeterminada
		\pre <em>Cert</em>
		\post El resultat és una àrea d'emmagatzematge buida
	*/
	Cjtcontenidors();

	// Destructora

	/** @brief Destructora
	      \pre <em>Cert</em>
	      \post Destrueix un objecte Cjtcontenidors
	*/   
	~Cjtcontenidors();

	// Modificadores

	/** @brief Modificadora que gestiona l'intent d'insertar un contenidor al conjunt de contenidors
		\pre String m que representa la matrícula, enter l (> 0) que representa longitud del contenidor,
			 u que representa l'ubicació i bool fromespera que representa un boleà que ens diu si el
			 contenidor que s'agrega prové de l'àrea d'espera o no
		\post Busca que el contenidor que s'agregui no tingui la mateixa matrícula que un altre del conjunt.
			  Si ja n'hi havia un, surt un error i retorna false. En cas contrari afegeix el contenidor al 
			  conjunt, retornarà true i si no prové de l'àrea d'espera mostrarà l'ubicació per pantalla
	*/
	bool agrega_contenedor(string m, int l, Ubicacion u, bool fromespera);

	/** @brief Modificadora que gestiona l'intent de retirar un contenidor de conjunt de contenidors
		\pre String m que representa la matrícula
		\post Busca que el contenidor sigui al conjunt. Si el troba, retira contenidor amb matrícula m
			  del conjunt de contenidors. Si no, surt un error
	*/
	void extreu_contenidor(string m);
    
    /** @brief Modificadora que inicialitza a buit el conjunt de contenidors
		\pre <em>Cert</em>
		\post Inicialitza el conjunt de contenidors
	*/
    void inicialitza_map();

    /** @brief Modificadora que canvia l'ubicació d'un contenidor per posar-lo a l'àrea d'espera
		\pre String m que representa la matrícula, enter l (> 0) que representa la longitud i u
			 que representa l'ubicació.
		\post Busca el contenidor amb matrícula m al conjunt. Si no el troba l'afegeix a partir dels
			  valors passats per paràmetre. Si el troba li canvia l'ubicació a la que es passa per 
			  paràmetre
	*/
    void espera(string m, int l, Ubicacion u);

	// Consultores

	/** @brief Consultora d'ubicació de contenidor
		\pre String m que representa la matícula
		\post El resultat és l'ubicació del contenidor amb matrícula m. Si no existeix
			  serà <-1, -1, -1>
	*/
	Ubicacion donde(string m) const;

	/** @brief Consultora de longitud del contenidor
		\pre String m que representa la matícula
		\post El resultat és la longitud del contenidor amb matrícula m. Serà -1 si
			  no existeix un contenidor amb matrícula m
	*/
	int longitud(string m) const;

	// Entrada/Sortida

	/** @brief Operació d'escriptura de tots els contenidors de la terminal
		\pre <em>Cert</em>
		\post Escriu els contenidors en ordre ascendent de la matrícula amb la seva 
			  ubicació i longitud --> m(<i,j,k>,l)
	*/
	void contenedores() const;
	
};

#endif
